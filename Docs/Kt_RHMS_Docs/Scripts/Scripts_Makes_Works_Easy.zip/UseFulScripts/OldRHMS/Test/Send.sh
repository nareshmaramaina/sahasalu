nc 202.53.78.186 5051

# Enter Below Data For Example, 

#Health#111817161507#

#END#
