wget --mirror --ftp-user=visiontek --ftp-password=Linkwell*123 --no-host-directories ftp://202.53.78.186/FIRMWARE
